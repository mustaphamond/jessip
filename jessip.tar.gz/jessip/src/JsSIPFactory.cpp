/*
 * JsSIPFactory.cpp
 *
 *  Created on: Jul 9, 2013
 *      Author: dcampbell
 */

#include "JsSIPFactory.h"

namespace jessip
{

JsSIPFactory::JsSIPFactory()
{
}

JsSIPFactory::~JsSIPFactory()
{
}

} /* namespace jessip */
