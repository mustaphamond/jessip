/*
 * main.cpp
 *
 *  Created on: Jan 8, 2013
 *      Author: dcampbell
 */

#include <stdio.h>
#include "Runtime.h"

int main(int argc, char* argv[])
{
   return jessip::Runtime::run(argc, argv);
}
